import type { AppProps } from 'next/app';
import '../styles/awusahrul_desain_tampilan.css'; 
function awusahrul({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />;
}

export default awusahrul;
